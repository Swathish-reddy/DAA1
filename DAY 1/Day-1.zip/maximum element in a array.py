nums = [3, 3, 3, 3, 3]
sorted_nums = sorted(nums)
max_element = max(sorted_nums)
print(max_element) 
