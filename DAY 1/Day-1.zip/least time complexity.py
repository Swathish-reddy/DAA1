nums = [1, 2, 3, 4, 5]
distinct_elements = set(nums)
count_distinct = len(distinct_elements)
print(count_distinct)  
