nums = [3, 7, 3, 5, 2, 5, 9, 2]
unique_elements = set(nums)
unique_list = list(unique_elements)
print(unique_list) 
